<?php $__env->startSection('style'); ?>
    <style>
        .dropdown-category{
            height: 500px;
            width: 100%;
            padding-top: 100px;
            justify-content: center;
        }
        .prod-cat{
            width: fit-content;
        }
        .form-label{

        }
        .form{
            width: 500px;
        }
    </style>
    <?php $__env->startSection('containers'); ?>
        <div class="containers">
            <div class="row dropdown-category">
                

                    <form class="form" method="POST" action="/UpdateFlower"  enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="flower_id" value="<?php echo e($flower->id); ?>">
                        <label class="visually-hidden" for="specificSizeSelect">Flower category </label>
                        <select class="form-select" name="flowerCategory" id="specificSizeSelect" style="width: 170px">
                        <option selected>Choose..</option>
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <div>
                            <label class="form-label" for="">Flower Name</label>
                            <input type="text" name="name" id="">
                        </div>
                        <div>
                            <label class="form-label" for="">Flower Price (Rupiah)</label>
                            <input type="number" name="flowerPrice" id="">
                        </div>
                        <div>
                            <label class="form-label" for="">Flower Description</label>
                            <input type="text" name="flowerDesc" id="">
                        </div>
                        <div>
                            <label class="form-label" for="">Flower Image</label>
                            <input type="file" name="flowerImg" id="" >
                        </div>

                        <input type="submit" value="pantek dek ang">
                    </form>
                  


            </div>
        </div>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('Navbar/Navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\S5\WebProg\Project\Flowelto\resources\views/UpdateProduct.blade.php ENDPATH**/ ?>