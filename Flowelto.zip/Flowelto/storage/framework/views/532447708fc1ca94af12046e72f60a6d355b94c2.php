<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="<?php echo e(asset('bootstrap-4.5.3-dist/css/bootstrap.min.css')); ?>">
    <title>Update</title>
    <style>
        body{
            background-color: #e6c5d7;
        }
        .header{
            background-color: #d10d79;
            display: flex;
            justify-content: space-between;
            width: 100%;
            position: fixed;
        }
        .navbar {
            background-color: #d10d79;
        }

        .content{
            display: flex;
            justify-content: center;
            padding-top: 80px;
        }
        .product{
            padding-left: 50px;
            display: flex;
            justify-content: space-between;
        }
        .detail{
            display: flex;
            flex-direction: column;
            padding: 100px;
        }
        .f-desc{
            width: 50%;
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <nav class="navbar navbar-expand-lg navbar-light ">
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                      <a class="nav-link" href="/Home">Flowelto Shop <span class="sr-only">(current)</span></a>
                    </li>
                  </ul>
                </div>
              </nav>
        </div>
        <div class="header-right">
            <nav class="navbar navbar-expand-lg navbar-light ">
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <ul class="navbar-nav mr-auto">
                    <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Catagories
                      </a>
                      <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="dropdown-item" href="http://127.0.0.1:8000/ViewCertainProd/<?php echo e($c->id); ?>"><?php echo e($c->name); ?></a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="http://127.0.0.1:8000/ViewAllProduct">All categories</a>
                      </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Manager
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="#">Add flower</a>
                          <a class="dropdown-item" href="#">Manage catagories</a>
                          <a class="dropdown-item" href="#">Change Password</a>
                          <a class="dropdown-item" href="#">Logout</a>
                        </div>
                      </li>
                  </ul>
                </div>
            </nav>
        </div>
    </div>

    <div class="content">
        <div class="product">
            <img class="imgDetail" src="<?php echo e(asset('assets/'.$flower->image)); ?>" height="500" width="500" alt="">
            <div class="detail">
                <h3 class="f-name"><?php echo e($flower->name); ?></h3>
                <h5 class="f-price">Rp <?php echo e($flower->price); ?></h5>
                <h6 class="f-desc"><?php echo e($flower->description); ?></h6>
            </div>

        </div>

    </div>

</body>
</html>
<?php /**PATH D:\Kuliah\S5\WebProg\Project\Flowelto\resources\views/FlowerDetail.blade.php ENDPATH**/ ?>