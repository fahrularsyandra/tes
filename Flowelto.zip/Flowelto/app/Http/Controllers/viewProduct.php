<?php

namespace App\Http\Controllers;

use App\Models\category;
use App\Models\flower;
use Illuminate\Http\Request;

class viewProduct extends Controller
{
    //
    function loadProduct(){
        $flower = flower::all();
        $category = category::all();
        return view('ViewProduct', ['flower'=>$flower, 'category'=>$category]);
    }
}
