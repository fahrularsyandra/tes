<?php

namespace App\Http\Controllers;
use Illuminate\Support\Facades\Validator;
//use App\Http\Controllers\Validator;
use App\Models\category;
use App\Models\flower;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class viewProductController extends Controller
{
    //untuk load data flower dan category untuk dipassing ke ViewAllProduct
    function loadAllProduct(){
        //mengambil semua data dari table flower
        $flower = flower::all();
        //mengambil semua data dari table category
        $category = category::all();
        return view('ViewAllProduct', ['flower'=>$flower, 'category'=>$category]);
    }
    //untuk load data flower category untuk menampilkan produk sesuai kategori, dan categories untuk bagian navbar pada bagian categories dipassing ke ViewCertainProd.
    function loadProduct($id){
        //untuk mengambil data flower yang sesuai dengan category yang sama dengan id
        $flower = DB::select('select * from flower where category = ?', [$id]);
        //untuk mengambil data category yang sesuai dengan id
        $category = category::where('id', $id)->first();
        //untuk mengambil semua category yang ada di table category
        $categories = category::all();
        return view('ViewCertainProd', ['flower'=>$flower, 'categories'=>$categories, 'category'=>$category]);
    }
    //untuk menampilkan 10 product utama dari database yang akan di pasising ke Home
    function loadHomeProduct(){
        //untuk select 10 data flower pertama yang ada di database
        $flower = DB::select('select * from flower where id <= ?', [10]);
        //untuk mengambil semua category yang ada di table category
        $category = category::all();
        return view('Home', ['flower'=>$flower, 'category'=>$category]);
    }
    //untuk menampilkan detail product pada view FlowerDetail.
    function loadFlowerDetail($id){
        //untuk menarik data flower sesuai $id
        $flower = flower::where('id',$id)->first();
        $category = category::all();
        //untuk mengambil semua category yang ada di table category
        return view('FlowerDetail', ['flower'=>$flower, 'category'=>$category]);
    }
    function loadAddProduct(){
        //mengambil semua data dari table flower
        //mengambil semua data dari table category
        $category = category::all();
        return view('AddProduct', ['category'=>$category]);
    }


    function AddProduct(Request $request){
        //melakukan validasi
        $validator = Validator::make($request->all(),[
            'name'=>'required | min:5 | unique:flower',
            'flowerPrice'=>'required | numeric | min:50000',
            'flowerDesc'=>'required | min:20',
            'flowerImg'=>'required'
        ]);

        //apabila validasi tidak sesua maka dia akan kembali ke halaman sebelumnya
        //jika benar dia akan melewatinya
        if ($validator->fails()){
            return redirect()->back()->withErrors($validator)->withInput();
        }
        dd('tes');
        //retrive category
        $category = category::where('id', $request->flowerCategory)->first();
        //mengambil nama file
        $img = $request->file('flowerImg')->getClientOriginalName();
        $imgName = pathinfo($img, PATHINFO_FILENAME);
        //mengambil jenis extension
        $ext = $request->file('flowerImg')->getClientOriginalExtension();
        //menggabungkan nama dan extension nya untuk di lempar ke attributes gambar pada tabel flower
        //dan nama akan di simpan sesuai nama filenya
        $filename = $imgName.'.'.$ext;
        //tempat file akan di simpan
        $path = $request->file('flowerImg')->storeAs('public/', $filename);
        // $img->move(public_path('assets/'.strtolower(Str::replaceLast(' ', '', $category->name))),$img->getClientOriginalName());
        //$img->move(public_path('assets/'.strtolower(Str::replaceLast(' ','',$category->name))),$img->getClientOriginalName());



        DB::insert('insert into flower (name, category, price, description, image)
        values (?, ?, ?, ?, ?)', [
                $request->name,
                $request->flowerCategory,
                $request->flowerPrice,
                $request->flowerDesc,
                $filename
            ]);
            $category = category::all();

            return redirect('/Home')->with(['category'=>$category]);
    }
    // function loadUpdateProduct(){

    //     $flower = flower::where('id', '=', $id)->first();

    //     return view('UpdateProduct', ['flower'=>$flower]);
    // }

    function UpdatePage($id){
        //mengambil data dari table flower sesuai dengan id yang ini di update
        $flower = flower::where('id', '=', $id)->first();
        //mengambil semua data dari table category untuk navbar
        $category = category::all();
        return view('UpdateProduct', ['flower'=> $flower, 'category'=> $category]);
    }

    function UpdateProduct(Request $request){
        //melakukan validasi

        $validator = Validator::make($request->all(),[
            'name'=>'required | min:5 | unique:flower',
            'flowerPrice'=>'required | numeric | min:50000',
            'flowerDesc'=>'required | min:20',
            'flowerImg'=>'required'
        ]);

        //apabila validasi tidak sesua maka dia akan kembali ke halaman sebelumnya
        //jika benar dia akan melewatinya
        if ($validator->fails()){
            return redirect()->back()->withErrors($validator)->withInput();
        }

        //retrive category
        $category = category::where('id', $request->flowerCategory)->first();
        //mengambil nama file
        $img = $request->file('flowerImg')->getClientOriginalName();
        $imgName = pathinfo($img, PATHINFO_FILENAME);
        //mengambil jenis extension
        $ext = $request->file('flowerImg')->getClientOriginalExtension();
        //menggabungkan nama dan extension nya untuk di lempar ke attributes gambar pada tabel flower
        //dan nama akan di simpan sesuai nama filenya
        $filename = $imgName.'.'.$ext;
        //tempat file akan di simpan
        $path = $request->file('flowerImg')->storeAs('public/', $filename);
        // $img->move(public_path('assets/'.strtolower(Str::replaceLast(' ', '', $category->name))),$img->getClientOriginalName());
        //$img->move(public_path('assets/'.strtolower(Str::replaceLast(' ','',$category->name))),$img->getClientOriginalName());


        DB::table('flower')::where('id','=',$request->id)->update([
            $request->name,
            $request->flowerCategory,
            $request->flowerPrice,
            $request->flowerDesc,
            $filename
        ]);
            $category = category::all();

            return redirect('/Home')->with(['category'=>$category]);
    }

}
