<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <link rel="stylesheet" href="{{asset('bootstrap-4.5.3-dist/css/bootstrap.min.css')}}">
    <title>View Product</title>
    <style>
        body{
            background-color: #e6c5d7;
        }
        .header{
            background-color: #d10d79;
            width: 100%;
            position: fixed;
            padding-right: 70px;
            display: flex;
            justify-content: space-between;
        }
        .navbar {
            background-color: #d10d79;
        }
        .search{
            padding-top: 70px;
            padding-left: 30px;
            width: max-content;
            display: flex;
            justify-content: flex-start
        }
        .btn-search{
            background-color: #fff;
            color: black;
        }
        .product-row{

        }
        .cat-name{
            margin: 30px;
            padding-left: 100px;
        }
        .product-col{
            padding: 10px 10px 10px 10px ;
            margin: 10px 10px 10px 10px ;
            width: 280px;
            height: 420px;
            background-color: #de81b3;
        }
        .img-class{
            background-color: #fff;
        }
        .img{
            display: flex;
            justify-content: center;
        }
        .product-name{
            margin: 30px;
            height: 40px;
        }
        .detail-btn{
            width: 120px;
        }
        .manager-detail-btn{
            display: flex;
            justify-content: center;
        }

    </style>
</head>
<body>
    <div class="header">
        <div class="header-left">
            <nav class="navbar navbar-expand-lg navbar-light ">
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                      <a class="nav-link" href="http://127.0.0.1:8000/Home">Flowelto Shop <span class="sr-only">(current)</span></a>
                    </li>
                  </ul>
                </div>
              </nav>
        </div>
        <div class="header-right">
            <nav class="navbar navbar-expand-lg navbar-light ">
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                  <ul class="navbar-nav mr-auto">
                    <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        Catagories
                      </a>
                      <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                        @foreach ($categories as $c)
                            <a class="dropdown-item" href="http://127.0.0.1:8000/ViewCertainProd/{{$c->id}}">{{$c->name}}</a>
                        @endforeach

                        <div class="dropdown-divider"></div>
                        <a class="dropdown-item" href="http://127.0.0.1:8000/ViewAllProduct">All categories</a>
                      </div>
                    </li>
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                          Manager
                        </a>
                        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                          <a class="dropdown-item" href="#">Add flower</a>
                          <a class="dropdown-item" href="#">Manage catagories</a>
                          <a class="dropdown-item" href="#">Change Password</a>
                          <a class="dropdown-item" href="#">Logout</a>
                        </div>
                      </li>
                  </ul>
                </div>
            </nav>
        </div>
    </div>

    <div class="search">
        <div class="dropdown">
            <button class="btn btn-secondary dropdown-toggle" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Name
            </button>
            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                @foreach ($categories as $c)
                    <a class="dropdown-item" href="http://127.0.0.1:8000/ViewCertainProd/{{$c->id}}">{{$c->name}}</a>
                @endforeach
            </div>
          </div>
          <form class="form-inline pl-1 my-2 my-lg-0">
            <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
            <button class="btn btn-outline-success my-2 my-sm-0 bg-light" type="submit">Search</button>
          </form>
    </div>
    <h3 class="cat-name">
        {{$category->name}}
    </h3>-
    @foreach (array_chunk($flower,4) as $chunk)
        <div class="product-row d-flex justify-content-center">
            @foreach ($chunk as $f)
                <div class="product-col">
                <a href="/FlowerDetail/{{$f->id}}">
                    <div class="img-class">
                        <img class="img d-flex justify-content-center"src="{{ asset('storage/'.$f->image)}}" height="250px" width="250px" class="bn-img" alt="{{ asset('assets/'.$f->image)}}" >
                    </div>

                </a>
                <h6 class="product-name d-flex justify-content-center">{{$f->name}}</h6>
                <div class="manager-detail-btn">
                    <a href=""><button type="button" class="btn btn-danger detail-btn">Delete</button></a>
                    <a href="/UpdateProduct/{{$f->id}}"><button type="button" class="btn btn-primary detail-btn">Update</button></a>


                </div>
            </div>
            @endforeach

        </div>
    @endforeach
</body>
</html>
