@extends('Navbar/Navbar')
@section('style')
    <style>
        .dropdown-category{
            height: 500px;
            width: 100%;
            padding-top: 100px;
            justify-content: center;
        }
        .prod-cat{
            width: fit-content;
        }
        .form-label{

        }
        .form{
            width: 500px;
        }
    </style>
    @section('containers')
        <div class="containers">
            <div class="row dropdown-category">
                {{-- <div class="col-sm-3 prod-cat" style=""> --}}

                    <form class="form" method="POST" action="/AddFlower" enctype="multipart/form-data">
                        @csrf
                        <label class="visually-hidden" for="specificSizeSelect">Flower category </label>
                        <select class="form-select" name="flowerCategory" id="specificSizeSelect" style="width: 170px">
                        <option selected>Choose..</option>
                        @foreach ($category as $c)
                            <option value="{{$c->id}}">{{$c->name}}</option>
                        @endforeach
                        </select>
                        <div>
                            <label class="form-label" for="">Flower Name</label>
                            <input type="text" name="name" id="">
                        </div>
                        <div>
                            <label class="form-label" for="">Flower Price (Rupiah)</label>
                            <input type="number" name="flowerPrice" id="">
                        </div>
                        <div>
                            <label class="form-label" for="">Flower Description</label>
                            <input type="text" name="flowerDesc" id="">
                        </div>
                        <div>
                            <label class="form-label" for="">Flower Image</label>
                            <input type="file" name="flowerImg" id="" >
                        </div>

                        <input type="submit" value="pantek dek ang">
                    </form>
                  {{-- </div> --}}


            </div>
        </div>
    @endsection
@endsection

