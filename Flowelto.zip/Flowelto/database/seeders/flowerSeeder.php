<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class flowerSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('flower')->insert([
            [//1
                'name'=>'Fresh Rose Hand Bouquet',
                'category'=>'1',
                'price'=>'450000',
                'description'=>'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa quae error iure quam! Cupiditate officia, quos soluta et minima magni dolore perferendis ad quasi placeat doloribus, quo delectus? Praesentium, error.',
                'image'=>'FreshRoseHandBouquet.jpg'
            ],
            [//2
                'name'=>'Magnolia Dried Flower',
                'category'=>'1',
                'price'=>'430000',
                'description'=>'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa quae error iure quam! Cupiditate officia, quos soluta et minima magni dolore perferendis ad quasi placeat doloribus, quo delectus? Praesentium, error.',
                'image'=>'MagnoliaDriedFlower.jpeg'
            ],
            [//3
                'name'=>'Luxury Colombian Hydrangea Bouquet',
                'category'=>'1',
                'price'=>'435000',
                'description'=>'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa quae error iure quam! Cupiditate officia, quos soluta et minima magni dolore perferendis ad quasi placeat doloribus, quo delectus? Praesentium, error.',
                'image'=>'LuxuryHydrangeaBouquetLondon.png'
            ],
            [//4
                'name'=>'Peach Rose Wedding Bouquet',
                'category'=>'2',
                'price'=>'525000',
                'description'=>'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa quae error iure quam! Cupiditate officia, quos soluta et minima magni dolore perferendis ad quasi placeat doloribus, quo delectus? Praesentium, error.',
                'image'=>'PeachRoseWeddingBouquet.png'
            ],
            [//5
                'name'=>'Purple Wedding Bouquet',
                'category'=>'2',
                'price'=>'525000',
                'description'=>'Lorem ipsum dolor sit amet consectetur adipisicing elit. Ipsa quae error iure quam! Cupiditate officia, quos soluta et minima magni dolore perferendis ad quasi placeat doloribus, quo delectus? Praesentium, error.',
                'image'=>'PurpleWeddingBouquet.jpg'
            ],
        ]);
    }
}
