<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class categorySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('category')->insert([
            ['name'=>'Hand Bouquet'],
            ['name'=>'Wedding Bouquet'],
            ['name'=>'Vase'],
            ['name'=>'table arrangement']
        ]);
    }
}
