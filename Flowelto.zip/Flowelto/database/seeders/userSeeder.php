<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class userSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //seeder user
        DB::table('users')->insert([
                'id'=>'1',
                'username'=>'admin',
                'email'=>'admin@flowelto.co',
                'password'=>'adminFlowelto',
                'gender'=>'Male',
                'dob'=>'1999-09-09',
                'address'=>"Gedung WTC Mangga Dua Lantai 6 Blok CL 001 Jl. Mangga Dua Raya No. 8 Jakarta Utara 14430",
                'role'=>'Manager'
        ]);

    }
}
